package it.gammainnovation.MicroServ1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServ1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
